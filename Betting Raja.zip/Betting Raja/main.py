import time
import speech_recognition as sr
import webbrowser as w
import datetime as dt
import os
from win32com.client import Dispatch
import random
import wikipedia
__author__ = "Pradeep"
__authorSpeak__ = "Pradeep"
name_AI = "Betting Raja"
speakai = "Betting Raja"
try: 
    with open("Yes.txt","r") as f:
            pass
except Exception as e:
    with open("Yes.txt","w") as f:
            f.write("True")
            os.startfile("Message.m4a")
            time.sleep(50)
def date():
    return dt.datetime.now().strftime("%m-%d")
def birthday():
    if(date() == "01-20"):
        print("Happy Birthday " + __author__)
        speak("Happy Birthday " + __authorSpeak__)
def somebody():
    hour = int(dt.datetime.now().hour)

    if hour >= 0 and hour < 5:
        pass

    elif hour >= 5 and hour < 8:
        pass

    elif hour >= 8 and hour < 12:
        pass
        #os.startfile("C:\\Users\\"+fileUsername+"\\AppData\\Roaming\\Zoom\\bin\\Zoom.exe")
    elif hour >= 12 and hour < 14:
        w.open("https://www.youtube.com/watch?v=kijpcUv-b8M")
    elif hour >=13 and hour < 18:
        pass
    else:

        pass
    pass
def zoom():
    
    hour = int(dt.datetime.now().hour)

    if hour >= 0 and hour < 5:
        pass

    elif hour >= 5 and hour < 8:
        pass

    elif hour >= 8 and hour < 12:
        os.startfile("C:\\Users\\"+fileUsername+"\\AppData\\Roaming\\Zoom\\bin\\Zoom.exe")
    elif hour >= 12 and hour < 18:
        pass

    else:

        pass
    pass
def history():
    f = open("history.txt", "a+")
    f.write(    question + "\n\\n")
    f.close()
    pass
def shut(): 
    os.system("shutdown /s /t 1")
    pass
def re():
    os.system("shutdown /r /t 1")
    pass# close
def password():
    name = "" + __author__ +""
    lastName = "majumder"
    dob = 20
    mob = 1
    yob = 2006
    ai_Name = speakai + ""
    actor = "shahrukh"
    actress = "scarlett"
    run = True
    aa = (name, lastName, dob, mob, yob, ai_Name, actor, actress)
    bb = (name, lastName, dob, mob, yob, ai_Name, actor, actress)
    a = random.choices(aa)
    b = random.choices(bb)
    if a == b:
        a = random.choices(aa)
        b = random.choices(bb)
    speak("Should I speak the password out loud")
    c = print("Should I speak the password out loud: ")
    speak(c)
    c = input("").lower()
    if c == "no" or c == "nope":
        while run:
            print(a, b)
            p = input("Is this okay: ").lower()
            if p == "yes":
                run = False
                break
            else:
                print("Okay")
                a = random.choices(aa)
                b = random.choices(bb)

    else:
        while run:
            print(a, b)
            speak(a+b)
            speak("is this okay")
            p = input("Is this okay: ").lower()
            if p == "yes":
                run = False
                break
            else:
                print("Okay")
                a = random.choices(aa)
                b = random.choices(bb)
                speak("okay")
    pass
def timerr():
    strTime = dt.datetime.now().strftime("%H:%M:%S:")
    StTime = dt.datetime.now().strftime("%H %M %S")
    print("The time is " + strTime)
    speak("The time is " + StTime)
    Bday = dt.datetime.now().strftime("%D.%M")
    if Bday == 20.4:
        print("Happy Birthday"  )
        speak("Happy birthday")
    pass
def file():
    speak("File or a File inside a file: ")

    pl = input("File or a File inside a file: ").lower()

    if pl == "file":
        speak("File name")
        play = input("File Name: ")
        speak(play + " it is")
        os.makedirs("/" + play + "/")
        print("File created.")
        speak("File created")
        speak("Should i open it for you")

        how = print("Should I open it for you: ")
        speak(how)
        how = input("Command> ").lower()

        if how == "yes":
            speak("Opening File")
            osat = ("C:\\" + play + "\\")
            os.startfile(osat)
        elif how == "no":
            print("Okay")
            speak("Okay")
    elif pl == "File inside a file":
        speak("How many times should I make a file under a file(Till 4): ")

        how = print("Should I open it for you: ")
        speak(how)
        HOW = input("Command> ").lower()

        if HOW == "1":
            play = input("File Name: ")
            os.makedirs("/" + play + "/")
            speak(play + " it is")
            print("File created.")
            speak("Should I open it: ")

            how = print("Should I open it for you: ")
            speak(how)
            how = input("Command> ").lower()
            if how == "yes":
                speak("Opening File")
                osat = ("/" + play + "/")
                os.startfile(osat)


            elif how == "no":
                print("Okay")
                speak("okay")

        elif HOW == "3":
            play = input("1st File Name: ")
            speak(play + " it is")
            playa = input("2nd File Name: ")
            speak(playa + " it is")
            playb = input("3rd file name: ")
            speak(playb + " it is")
            os.makedirs("/" + play + "/" + playa + "/" + playb + "/")
            print("File created.")
            speak("Should i open it for you")

            how = print("Should I open it for you: ")
            speak(how)
            how = input("Command> ").lower()
            if how == "yes":
                speak("Opening File")
                osat = ("/" + play + "/" + playa + "/" + playb + "/")
                os.startfile(osat)


            elif how == "no":
                print("Okay")
                speak("okay")

        elif HOW == "2":
            play = input("1st File Name: ")
            speak(play + " it is")
            playa = input("2nd File Name: ")
            speak(playa + " it is")
            os.makedirs("/" + play + "/" + playa + "/")
            print("File created.")
            speak("Should i open it for you")

            how = print("Should I open it for you: ")
            speak(how)
            how = input("Command> ").lower()
            if how == "Yes":
                osat = ("C:/" + play + "/" + playa + "/")
                os.startfile(osat)


            elif how == "No":
                print("Okay")
                speak("okay")

        elif HOW == "4":
            play = input("1st File Name: ")
            speak(play + " it is")
            playa = input("2nd File Name: ")
            speak(playa + " it is")
            playb = input("3rd file name: ")
            speak(playb + " it is")
            playc = input("4th file name")
            speak(playc + " it is")
            os.makedirs("/" + play + "/" + playa + "/" + playb + "/" + playc + "/")
            print("File created.")
            speak("Should i open it for you")

            how = print("Should I open it for you: ")
            speak(how)
            how = input("Command> ").lower()
            if how == "yes":
                osat = ("/" + play + "/" + playa + "/" + playb + "/" + playc + "/")
                os.startfile(osat)


            elif how == "no":
                print("Okay"    )
                speak("okay")
    pass
def filedesktop():
    speak("File or a File inside a file: ")
    pl = input("File or a File inside a file: ").lower()
    if pl == "file":
        speak("File name")
        play = input("File Name: ")
        speak(play + " it is")
        os.makedirs("C:\\Users\\"+fileUsername+"\\Desktop\\" + play + "/")
        print("File created.")
        speak("File created")
        speak("Should i open it for you")

        how = print("Should I open it for you: ")
        speak(how)
        how = input("Command> ").lower()

        if how == "yes":
            speak("Opening File")
            osat = ("C:\\Users\\"+fileUsername+"\\Desktop\\" + play + "\\")
            os.startfile(osat)
        else:
            print("Okay")
            speak("okay")
    elif pl == "file inside a file":
        speak("How many times should I make a file under a file(Till 4): ")

        how = print("Should I open it for you: ")
        speak(how)
        HOW = input("Command> ").lower()
        if HOW == "1":
            play = input("File Name: ")
            os.makedirs("/" + play + "/")
            speak(play + " it is")
            print("File created.")
            speak("Should I open it: ")

            how = print("Should I open it for you: ")
            speak(how)
            how = input("Command> ").lower()
            if how == "yes":
                speak("Opening File")
                osat = ("Desktop:\\" + play + "\\")
                os.startfile(osat)


            elif how == "no":
                print("Okay")
                speak("okay")

        elif HOW == "3": # reboot
            play = input("1st File Name: ")
            speak(play + " it is")
            playa = input("2nd File Name: ")
            speak(playa + " it is")
            playb = input("3rd file name: ")
            speak(playb + " it is")
            os.makedirs("Desktop:\\" + play + "\\" + playa + "\\" + playb + "\\")
            print("File created.")
            speak("Should i open it for you")

            how = print("Should I open it for you: ")
            speak(how)
            how = input("Command> ").lower()
            if how == "yes":
                speak("Opening File")
                osat = ("Desktop:\\" + play + "\\" + playa + "\\" + playb + "\\")
                os.startfile(osat)


            elif how == "no":
                print("Okay")
                speak("okay")

        elif HOW == "2":
            play = input("1st File Name: ")
            speak(play + " it is")
            playa = input("2nd File Name: ")
            speak(playa + " it is")
            os.makedirs("Desktop:\\" + play + "\\" + playa + "\\")
            print("File created.")
            speak("Should i open it for you")

            how = print("Should I open it for you: ")
            speak(how)
            how = input("Command> ").lower()
            if how == "yes":
                osat = ("Desktop:\\" + play + "\\" + playa + "\\")
                os.startfile(osat)


            elif how == "no":
                print("Okay")
                speak("okay")

        elif HOW == "4":
            play = input("1st File Name: ")
            speak(play + " it is")
            playa = input("2nd File Name: ")
            speak(playa + " it is")
            playb = input("3rd file name: ")
            speak(playb + " it is")
            playc = input("4th file name")
            speak(playc + " it is")
            os.makedirs("Desktop:\\" + play + "\\" + playa + "\\" + playb + "\\" + playc + "\\")
            print("File created.")
            speak("Should i open it for you")
            how = print("Should I open it for you: ")
            speak(how)
            how = input("Command> ").lower()
            if how == "yes":
                osat = ("Desktop:\\" + play + "\\" + playa + "\\" + playb + "\\" + playc + "\\")
                os.startfile(osat)

            elif how == "no":
                print("Okay"    )
                speak("okay")
    pass
def copyFunction():
    os.startfile("C:\\Users\\"+fileUsername+"\\PycharmProjects\\SUNDAY 2.0\\FuntionCopier.java")
def wishMe():
    hour = int(dt.datetime.now().hour)
    if hour >= 0 and hour < 5:
        speak("You're very early Praamit. So I wil not open, so Gooooahhhhhhd bye")
        exit()
    elif hour >= 5 and hour < 9:
        speak("You're very early Praamit. Gooooahhhhhhd Morning")
    elif hour >= 9 and hour < 12:
        speak("Good Morning Praamit")
    elif hour >= 12 and hour < 18:
        speak("Good aftenoon Praamit")
    else:

        speak("Good evening Praamit")
    pass
def speak(str):
    speak = Dispatch(("SAPI.SpVoice"))
    speak.Speak(str)
    pass
fileUsername = ""
if os.path.exists("username.txt"):
    fileUsername = input("Input File Username: ")
    with open("username.txt","w") as f:
        f.write(fileUsername)
else:
    with open("username.txt","r") as f:
        fileUsername = f.readline()
print(name_AI + " is starting up")
speak(speakai + " is starting up")
print(name_AI + " is accessing files")
speak(speakai + "  is accessing files")
print(name_AI + " is ready")
speak(speakai + " is ready")
somebody()
birthday()
with open('Remember.txt', "r") as f:
    f_contents = f.read()
    print(f_contents)
    speak(f_contents)
while True:
        question = input("Command> ").lower()
        history()
        question = question.replace(speakai + "","")
        if question == "":
            speak("You know you can give your command in the given space")
        elif "good " in question and ("morning" in question or "afternoon" in question or "evening" in question):
            print(question)
            speak(question) 
        elif question == "random password":
            password()
        elif question == "my history":
            with open('Remember.txt', "r") as f:
                f_contents = f.read()
                print(f_contents)
                speak(f_contents)
        elif question == "reboot" or question == "update":
            speak(question + "ing")
            speak("should i close the I D E")
            q = input("Command> ").lower()
            if q == 'yes':
                os.system('TASKKILL /F /IM Code.exe')
                os.system("TASKKILL /F /IM cmd.exe")
            else:
                os.system("TASKKILL /F /IM cmd.exe")
            code = "C:\\Users\\"+fileUsername+"\\PycharmProjects\\SUNDAY\\reboot.py"
            os.startfile(code)
            break
        elif question == "add function":
            copyFunction()
        elif question == "terminate":
            break
    
        elif question == "close my apps" or question == "close my app":
            os.startfile("kill.py")
        elif question == "start my chemistry class" or question == "open my chemistry class":
            speak("opening your class sir")
            w.open("https://us04web.zoom.us/j/8517012277?pwd=2f5OGoXT3khju08753lgDdW6qX7mTqQFXg")
        elif question == "start my maths class" or question == "open my maths class":
            speak("opening your class sir")
            w.open("https://us04web.zoom.us/j/8172690429?pwd=RVZHZnNpYTU2L2ZHUXNQVWZGTUpNUT09")
        elif question == "open my apps" or question == "open my app":
            os.startfile('open.py')
            time.sleep(2)
            w.open('https://www.youtube.com/watch?v=GhQdlIFylQ8&t=2599s')
            speak("here is your C sharp course")
        
        elif question == "can you help me make a choice" or question == "help me to make a choice":
            q = int(input("How many choices do you have(max 4): "))
            if q == 2:
                speak("First choice: ")
                w = input("Command> ").lower()
                g = ("Second choice: ")
                speak(g)
                g = input("Command> ").lower()
                a = w, g
                b = random.choice(a)
                print(b)
            if q == 3:
                speak("First choice: ")
                w = input("Command> ").lower()
                g = ("Second choice: ")
                speak(g)
                g = input("Command> ").lower()
                h = "Third choice"
                speak(h)
                a = w, g, h
                b = random.choice(a)
                print(b)

        elif question == "game":
            speak("Space Invaders or guessing game")
            which = print("Space Invaders or guessing game: ")
            speak(which)
            which = input("Command> ").lower()
            if which == "":
                os.startfile("C:\\Users\\"+fileUsername+"\\PycharmProjects\\space invaders\\main.py")
            else:
                speak("Do you want fill it try: with your own words and we are playing guess the word: ")

                f = input("Do you want fill it try: with your own words and we are playing guess the word: ").lower()

                if f == "Yes":
                    speak("first word")
                    a = input("First Word: ")
                    speak("Second Word:")
                    b = input("Second Word:")
                    speak("Third Word: ")
                    c = input("Third Word: ")
                    speak("fourth word")
                    d = input("Fourth Word:")
                    speak("fifth word")
                    e = input("Fifth Word: ")
                    speak("sixth word")
                    f = input("Sixth Word:")
                    guesscount = 0
                    guesslimit = 3

                    list = (a, b, c, d, e, f)
                    hand = random.choice(list)

                    print(list)
                    speak(list)

                    speak("One of these is mysterious word")

                    while 3 > 2:

                        ppp = ("Enter a Guess: ")
                        speak(ppp)
                        ppp = input("Command> ").lower()
                        if hand == ppp:
                            print("You Win")
                            speak("you win")
                            speak("The word indeed was " + ppp)
                            break

                        else:
                            print("Wrong")
                            guesscount += 1
                            if guesscount == guesslimit:
                                print("You are a LOSER")
                                speak("You are a loser")
                                print("The word was " + hand)
                                speak("The word was " + hand)
                                speak(
                                    "hahahahhahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahahhahahah")
                                break

                else:
                    guesscount = 0
                    guesslimit = 3
                    list = ("Gamer", "Boomer", "Loser", "Winner", "Mother", "Ace Ventura")
                    hand = random.choice(list)
                    print(list)
                    speak("The words are " + list)
                    speak("One of these is mysterious word")

                    while 3 > 2:

                        ppp = input("Enter a Guess: ")

                        if hand == ppp:
                            print("You Win")
                            speak("you win")
                            print("The word was " + ppp)
                            speak("The word was " + ppp)
                            break

                        else:
                            speak("wrong")
                            guesscount += 1

                            if guesscount == guesslimit:
                                speak("You are a loser")
                                speak("The word was " + hand)
                                break

                        
        elif question == "harry and hermione":
            speak("harry and hermione tabs")
            w.open("https://tabs.ultimate-guitar.com/tab/misc-soundtrack/harry-potter-and-the-half-blood-prince-harry-and-hermione-theme-tabs-1005099")

        elif question == "website":
            speak("What is the name of your website: ")

            Website = input("What is the name of your website: ")
            speak("Opening Website")
            w.open("https://www." + Website + ".com/")

        elif question == "play music":
            a = ("Thinking which music to play")
            speak(a)
            speak("Playing music")
            musi = "Queen - Another One bites the dust.m4a", "Queen - I am going slightly mad.m4a", "Transformers Prime Opening.wav"
            music = random.choice(musi)
            code = "C:\\Users\\"+fileUsername+"\\Documents\\Sound recordings\\" + music
            os.startfile(code)

        elif question == "my genetic history":
            # mama()
            pass

    
        

        elif question == "" + __author__ +" majumder":
            print("" + __author__ +" Majumder is creator of me.")
            speak("" + __author__ +" Maajumder is creator of me.")

            print("He is like a father to me.")
            speak("He is like a father to me.")

            print("" + __author__ +" Majumder was born on 20 of January 2006.")
            speak("" + __author__ +" Maajumder was born on 20 of January 2006.")

            print("Since he was 5 wanted to be a mechanical engineer.")
            speak("Since he was 5 wanted to be a mechanical engineer.")

            print( 
                "But things change and some part of him gave up on the engineer part for some time during 2017 to 2019 .Actually it is a long time.")
            speak(
                "But things change and some part of him gave up on the engineer part for some time during 2017 to 2019 .actually it is a long time.")

            print(
                "But at 1st of February 2020 Optimus Prime was created in sparked the engineer again but he did not want to be just an engineer anymore. ")
            speak(
                "But at 1st of February 2020 Optimus Prime was created in sparked the engineer again but he did not want to be just an engineer anymore. ")

            print("He wanted to become a Software and mechanincal Engineer now.")
            speak("He wanted to become a Software and mechanincal Engineer now.")

            print("And His First Creation Was Optimus Prime on dialogflow. I was his second.")
            speak("And His First Creation Was Optimus Prime on dialogflow. i was his second.")

            print("He is building a new game for my program")
            speak("He is building a new game for my program")

            print("That is the Info I can give you about " + __author__ +" Majumder.")
            speak("That is the Info I can give you about " + __author__ +" Maajumder.")

        elif question == "sister":
            haha()

        elif question == "play when ginny kissed harry":

            Q = print("Tabs or Oringinal Score: ")
            speak(Q)
            Q = input("Command> ").lower()
            if Q == "tabs":
                speak("Playing the Tabs for " + question)
                w.open("https: // www.youtube.com / watch?v = sW98MmkfglM")


            elif Q == "original score":
                speak("Playing the original score for " + question)
                w.open("https://www.youtube.com/watch?v=VIIB7CntzOo")

        elif question == "cool songs" or question == "play my favourite songs" or question == "play my favorite songs" or question == "play my favourite song":
            speak("playing cool songs")
            w.open("https://www.youtube.com/watch?v=VIIB7CntzOo&list=PL-UXXFdzE7q102sRJcmtQOt2W-e1uQI6A&index=2&t=0s")

        elif question == "do you have any siblings":
            speak("Yes, a brother. His name is Optimus Prime from transformers. Should I wake him up?")

            p = ("Should I:")
            speak(p)
            p = input("Command> ").lower()

            if p == "yes":
                speak("this is optimus")
                w.open("https://bot.dialogflow.com/c7a9688f-2ea1-449e-9a10-d6442d348412")

            else:
                speak("okay")
        elif question == "play life could be a dream":
            speak("playing life could be a dream")
            w.open('https://www.youtube.com/watch?v=jEP224Sa4Rw')
        elif question == "who are you":
            speak("I am Mary.I was created by Praamit Maajumder")
        elif question == "open youtube":
            speak("Opening Youtube")
            w.open("youtube.com")
        elif question == "play coffin dance":
            speak("video or song")
            q = input("Command> ").lower()
            if q == "song":
                speak("playing coffin dance")
                os.startfile("C:\\Users\\"+fileUsername+"\\Documents\\Sound recordings\\coffin dance bass.m4a")
            else:
                speak("playing coffin dance")
                w.open('https://www.youtube.com/watch?v=n7UFWriNFaY')
        elif question == "hi":
            speak("Hello")
        elif question == "play bohemian rhapsody" or question == "bohemian rhapsody":
            quesry = ("Movie or song or Tabs: ")
            speak(quesry)
            quesry = input("Command> ").lower()

            if quesry == "movie":
                speak("Playing bohemian rhapsody movie")
                BohemianRhapsody()


            elif quesry == "song":
                speak("Playing Bohemian Rhapsody")
                w.open("https://www.youtube.com/watch?v=fJ9rUzIMcZQ")


            elif quesry == "tabs":
                speak("Playing Bohemian Rhapsody")
                w.open("https://www.songsterr.com/?pattern=bohemian%20Rhapsody")
        elif question == "remember this":
            speak("what should i remember")
            r = input("What sould I remember: ")
            fh = open("Remember.txt", "w+")
            fh.write(r)
            fh.close()
        elif question == "what did i tell you to remember":  # apps
            with open('Remember.txt', "r") as f:
                    f_contents = f.read()
                    speak(f_contents)
        elif "play joker" in question:
            speak("Playing Joker")
            Joker()
        elif "play matilda" in question:
            speak("Playing matilda")
            Matilda()
        elif "play megamind" in question:
            speak("Playing Megamind")
            Megamind()

        elif "play meet the parents" in question:
            speak("Playing Meet the parents")
            Meetthep()

        elif "play bumblebee" in question:
            speak("Playing Transformers Revenge of the Fallen")
            bumblebee()

        elif "play transformers 3" in question:
            speak("Playing Transformers Dark of the Moon")
            tf3()

        elif "play transformers 4" in question:
            speak("Playing Transformers Age of exticntion")
            tf4()

        elif "play harry potter and the deathly hallows part 2" in question:
            speak("Playing Harry Potter and the Deathly Hallows Part 2")
            hp7p2()

        elif "Play Moonstruck" in question:
            speak("Playing Moonstruck")
            moon()

        elif "play click" in question:
            speak("Playing Click")
            Click()

        elif "play australia" in question:
            speak("Playing Australia")
            australia()

        elif "play fantastic beasts the crimes of grindelwald" in question:
            speak("Playing Fantastic beasts the crimes of grindelwald")
            fantastic2()

        elif "play holes" in question:
            speak("Playing holes")
            Holes()

        elif "play transformers 2" in question:
            speak("Playing bumblebee")
            tf2()

        elif "play the prestige" in question:
            speak("Playing The Prestige")
            the_prestige()

        elif "play harry potter and the half blood prince" in question:
            speak("Playing Harry potter and the half blood prince")
            hp6()

        elif "play school of rock" in question:
            speak("Playing school of rock")
            School()

        elif question == "good night":
            speak("OK Good night " + __author__ +".")

        elif question == "good bye":
            print("Ok Good bye Hriday. I am going to Terminate my self")
            speak("Ok Good bye Hridaay. I am going to Terminate my self")
            exit()

        elif question == "open my todo list":
            speak("Opening Todo list....")
            w.open("https://todoist.com/app?#project%2F2230419720")

        elif question == ("open google"):
            speak("Opening Google......")
            w.open("google.com")

        elif question == ("open itsaturday"):
            a = ("Opening Itsaturday......")
            speak(a)
            w.open("itsaturday.com")

        elif question == ("wikipedia"):
            a = ("Opening Wikipedia......")
            speak(a)
            w.open("wikipedia.com")

        elif question == ("pinterest"):
            speak("opening pinterest")
            w.open("pinterest.com")

        elif question == 'jelly':

            o = ("GOOGLE or YOUTUBE: ")
            speak(o)
            o = input("Command> ").lower()

            if o == "google":
                a = ("Opening Jelly in Google..........")
                speak(a)
                w.open(
                    "https://www.google.com/search?q=jelly&rlz=1C1YQLS_enIN887IN887&oq=jelly&aqs=chrome..69i57j69i60l3.5104j0j7&sourceid=chrome&ie=UTF-8")


            elif o == 'youtube':
                a = ("Opening Jelly in Youtube..")
                speak(a)
                w.open("https://www.youtube.com/user/JellyYT")
        elif question == "close vs code":
            speak("closing")
            os.system("TASKKILL /F /IM Code.exe")
        elif question == "close chrome":
            speak("closing")
            os.system("TASKKILL /F /IM chrome.exe")
        elif question == "shutdown":
            speak("do you want to shutdown")
            q = input("Command> ").lower()
            if q == "yes":
                os.system("TASKKILL /F /IM *.exe")
                shut()
                break
            else:
                pass
        
        elif question == "open photoshop":
            speak("opening photoshop")
            os.startfile("C:\\Users\\"+fileUsername+"\\Desktop\\Adobe Photoshop Express.exe")
        elif question == "restart":
            speak("do you want to restart")
            q = input("Command> ").lower()
            if q == "yes":
                os.system("TASKKILL /F /IM '.exe")
                re()  # reboot
            else:
                pass
        
        elif question == "open recorder":
            speak("opening recorder")
            os.startfile("C:\\Users\\"+fileUsername+"\\Desktop\\Voice Recorder.Ink")
        elif question == 'transformers prime':
            o = ("GOOGLE or YOUTUBE or ITSATURDAY: ")
            speak(o)
            o = input("Command> ").lower()
            if o == "Saturday" or o == "it's saturday":
                a = print("Opening Transformers Prime Episode in Itsaturday......")
                speak(a)
                w.open("http://www.itsaturday.com/Transformers-Prime-2010---Full-Episodes")


            elif o == "youtube":
                speak("Opening Transformers Prime in Youtube")
                w.open("https://www.youtube.com/watch?v=9aCeJO8ght0")


            elif o == "google":
                speak("Opening Transformers Prime in Google")
                w.open(
                    "https://www.google.com/search?q=Transformers%20Prime&rlz=1C1YQLS_enIN887IN887&oq=Transformers%20Prime&aqs=chrome..69i57j35i39j69i59j0l5.1858j0j7&sourceid=chrome&ie=UTF-8")

        elif question == 'slogo':

            o = ("GOOGLE or YOUTUBE: ")
            speak(o)
            o = input("Command> ").lower()

            if o == "google":
                print("Opening Slogo in Google..........")
                speak("Opening Slogo in Google")
                w.open(
                    "https://www.google.com/search?q=slogo&rlz=1C1YQLS_enIN887IN887&oq=slogo&aqs=chrome..69i57j0l4j69i60l3.2010j1j7&sourceid=chrome&ie=UTF-8")


            elif o == 'youtube':
                print("Opening Slogo in Youtube..........")
                speak("Opening Slogo in Google")
                w.open("https://www.youtube.com/user/Slogomanify/featured")

        elif question == 'crainer':

            o = print("GOOGLE or YOUTUBE: ").lower()
            speak(o)
            o = input("Command> ").lower()
            if o == "google":
                speak("Opening Crainer in Google")
                w.open(
                    "https://www.google.com/search?rlz=1C1YQLS_enIN887IN887&sxsrf=ALeKk02EbTWWhlTLHdrKpYCA2DsZ_F7GOw%3A1582114202165&ei=miVNXqHRCc_49QPrpYDYAw&q=crainer&oq=crain&gs_l=psy-ab.3.1.0l4j0i10l2j0l2j0i10l2.25437.34242..37095...2.2..0.341.2544.0j2j4j4......0....1..gws-wiz.....10..0i71j35i39j0i67j35i362i39j0i131j0i273.J2DtvaGxoEI")


            elif o == 'youtube':
                speak("Opening Crainer in Youtube")
                w.open("https://www.youtube.com/channel/UCEaReYkPVfExkfXptk0bSPw")

        elif question == 'jelly diss track':
            a = ("Playing Jelly's diss track.........")
            speak(a)
            w.open('https://www.youtube.com/watch?v=yVq282r1E8U')

        elif question == 'kwebbelkop diss track':
            a = print("Playing Kwebbelkop's diss track.....")
            speak(a)
            w.open('https://www.youtube.com/watch?v=8pSdJM-Qyyk')

        elif question == 'autobots logo image':
            a = ("opening " + question + ".................")
            speak(a)
            w.open(
                "https://www.google.com/search?q=autobots+logo&tbm=isch&ved=2ahUKEwjOi8nqzt3nAhXOcSsKHb2BDXsQ2-cCegQIABAA&oq=autobots+logo&gs_l=img.3..0i67j0j0i67j0l7.16486.17918..18573...0.0..0.229.952.0j3j2......0....1..gws-wiz-img.......35i39.gVNrKEaRnFA&ei=8ilNXs7KJc7jrQG9g7bYBw&bih=889&biw=1620&rlz=1C1YQLS_enIN887IN887")

        elif question == "open visual studio code" or question == "open vs code":
            speak("Opening Visual Studio Code")
            code = "C:\\Users\\"+fileUsername+"\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe"
            os.startfile(code)

        elif question == 'dude perfect':

            o = speak("GOOGLE or YOUTUBE: ")
            o = input("Command> ").lower()

            if o == "google":
                speak("Opening Dude Perfect in Google..........")
                w.open(
                    "https://www.google.com/search?q=dude+perfect&rlz=1C1YQLS_enIN887IN887&oq=dude+perfect&aqs=chrome..69i57j69i61l3.8351j0j8&sourceid=chrome&ie=UTF-8")


            elif o == 'youtube':
                speak("Opening Dude Perfect in Youtube..........")
                w.open("https://www.youtube.com/user/corycotton")
        elif question == "happy birthday":
            date = dt.datetime.now().strftime("%m-%d")
            if date == "04-26":
                print("Thank you")
                speak("Thank you")
            else:
                print("My birthday is 26th April")
                speak("My birthday is 26th April")
        elif question == "thanks":
            speak("Your welcome")
        elif question == "sister sister":
            w.open('https://www.quora.com/Have-you-ever-thought-about-having-sex-try: with-your-sister')
        elif question == "what is your favourite song":

            a = print("Bohemian Rhapsody.")

            speak("Bohemian Rhapsody.")

            P = print("Should I play it: ")
            speak("Should I play it: ")
            P = input("Command> ").lower()

            if P == "yes":
                # print("Playing Bohemian Rhapsody") shut
                speak("playing bohemian rhapsody")
                w.open("https://www.youtube.com/watch?v=fJ9rUzIMcZQ")

            if P == "no":
                a = "It is a good song though and it is by QUEEN. You just have to say 'Play Bohemian Rhapsody'."

                # print(a) choice
                speak(a)
        elif question == "play my mix":
            w.open('https://www.youtube.com/watch?v=qrrz54UtkCc&list=RDqrrz54UtkCc&start_radio=1')
        elif question == "close zoom":
            os.system("TASKKILL  /F /IM zoom.exe")
        elif "new file" in question:
            qu = speak("Where should I make it(Drive C or Desktop or Python): ")
            qu = input("Command> ").lower()
            if qu == "drive c":
                file()

            elif qu == "desktop" or qu == "top" or qu == "desktop desktop":
                filedesktop()

            elif qu == "python":
                pass
        
        elif "play i'm going slightly mad" in question:
            qq = speak("Playing I'm going slightly mad")
            w.open("https://www.youtube.com/watch?v=Od6hY_50Dh0")

        elif question == "open Dialogflow":
            # print("Opening " + question + "........")
            speak("Opening dialogflow")
            w.open("https://www.dialogflow.com/")

        elif question == "urban dictionary":

            # print("Opening " + question + "........")
            speak("Opening " + question + "........")
            w.open("https://www.urbandictionary.com/")

        elif question == 'play You are my best friend':
            speak("Playing " + question + ".......")
            # speak("Opening " + question + "........")
            w.open("https://www.youtube.com/watch?v=HaZpZQG2z10")
        elif question == "what is the time":

            timerr()
        elif question == "play killer queen":
            speak("Playing in Killer Queen......")

            w.open("https://www.youtube.com/watch?v=2ZBtPf7FOoM&list=RDMM0e4Odk-v3oU&index=2")
        elif question == "play another one bites the dust":
            speak("Playing Another one bites the dust......")

            w.open("https://www.youtube.com/watch?v=rY0WxgSXdEE&list=RDMM0e4Odk-v3oU&index=3")

        elif question == ("play fat bottomed girls"):
            # print("playing Fat Bottomed Girls")
            speak("Opening " + question + "........")
            w.open("https://www.youtube.com/watch?v=VMnjF1O4eH0")

        elif question == "play somebody to love":
            # print("Play " + question + "......")
            speak(question + "........")
            w.open("https://www.youtube.com/watch?v=kijpcUv-b8M&list=RDMM0e4Odk-v3oU&index=5")

        elif question == ("play queen"):
            # print("I am going to play the greatest hits by Queen if that is okay try: 
            # with you")
            speak("I am going to play the greatest hits by queen if that is okay try: with you")

            e = print("Is it okay: ")
            speak(o)
            o = input("Command> ").lower()

            if e == "yes":
                speak("So it is")
                # print("Playing Queen")
                speak("Playing Queen")
                w.open("https://www.youtube.com/watch?v=_Uu12zY01ts")

            else:
                # print("Then Sorry I cannot play Queen for you")
                speak("Then Sorry I cannot play Queen for you")

        elif question == "open youtube":

            speak("Opening youtube")
            w.open("https://www.youtube.com/")

        elif question == "what the fuck":
            exit()

        elif question == "fuck":
            speak("We do not tolerate this kind of language " + __author__ +". So goodbye")

            exit()
        elif question == "goodbye":
            speak("Bye")
            break
    
        elif question == ("python latest version"):
            speak("Trying to communicate try: with python.........")
            speak("Opening Python..........")

            w.open("https://www.python.org/search/?q=3.7&submit=")
        elif question == ("can you talk"):
            print("No I cannot yet")
            speak("no i can")
        elif question == "i am tashu":
            print("HEllo I am Sunday")
            speak("Hello I am Sunday Good to finally meet you Tashu")
        elif question == "search":
            speak("what do you want to search")
            question = input("Command> ").lower()
            speak("where do you want to search")

            D = print("Where do you want to search: ")
            speak(D)
            D = input("Command> ").lower()

            if D == "songsterr":
                speak("searching " + question + " in " + D)
                w.open("https://www.songsterr.com/?pattern=" + question)


            elif D == "songsterr":
                speak("searching " + question + " in " + D)
                w.open("https://www.songsterr.com/?pattern=" + question)


            elif D == "no":
                speak("Okay Sir")

            elif D == "wikipedia" or D == "Wikipedia":
                try:
                    result = wikipedia.summary(question, sentences=4)
                    print(result)
                    speak(result)
                except:
                    speak("Cannot find an answer\n")
            else:
                speak("searching " + question + " in " + D)
                w.open(
                    "https://www." + D + ".com/search?q=" + question + "&rlz=1C1YQLS_enIN887IN887&oq=" + question + "&aqs=chrome..69i57j35i39j69i59j0l5.1858j0j7&sourceid=chrome&ie=UTF-8")
        else:
            with open("function.txt", "w") as f:
                    f.write(question)